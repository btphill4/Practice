# This program prints Hello, world!
msg = "Hello World"
print(msg)